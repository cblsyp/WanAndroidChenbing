package com.pingpang.wanandroidchenbing.app

import android.app.Application
import android.content.Context
import kotlin.properties.Delegates

class App:Application(){
    companion object{
        val TAG="wan_android"
        val context:Context by Delegates.notNull()
           private set
        lateinit var instance:Application


    }
}